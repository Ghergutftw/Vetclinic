create definer = myuser@`%` view cda as
select `c`.`id`                  AS `consultation_id`,
       `c`.`date`                AS `consultation_date`,
       `c`.`doctor_id`           AS `doctor_id`,
       `c`.`animal_id`           AS `animal_id`,
       `c`.`diagnostic`          AS `diagnostic`,
       `c`.`treatment`           AS `treatment`,
       `c`.`recommendations`     AS `recommendations`,
       `d`.`id`                  AS `doctor_id_d`,
       `d`.`first_name`          AS `doctor_firstName`,
       `d`.`last_name`           AS `doctor_lastName`,
       `d`.`speciality`          AS `doctor_speciality`,
       `d`.`age`                 AS `doctor_age`,
       `d`.`years_of_experience` AS `doctor_yearsOfExperience`,
       `a`.`id`                  AS `animal_id_a`,
       `a`.`nickname`            AS `animal_nickname`,
       `a`.`animal_type`         AS `animal_animalType`,
       `a`.`specie`              AS `animal_specie`,
       `a`.`age`                 AS `animal_age`,
       `a`.`weight`              AS `animal_weight`
from ((`mydatabase`.`consultations` `c` left join `mydatabase`.`doctor` `d`
       on ((`c`.`doctor_id` = `d`.`id`))) left join `mydatabase`.`animal` `a` on ((`c`.`animal_id` = `a`.`id`)));

